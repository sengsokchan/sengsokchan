package graphics;

import javax.swing.*;

public class GraphicsExample extends JFrame {
    //PanelDrawing panelDrawing = new PanelDrawing();
    public GraphicsExample(){
        PanelDrawingThread panelDrawingThread = new PanelDrawingThread();
        add(panelDrawingThread);

        //PanelDrawing panelDrawing = new PanelDrawing();
        //add(panelDrawing);

        setBounds(300,400, 600,300);
        setVisible(true);
    }

    public static void main(String[] args) {
        new GraphicsExample();

    }
}
