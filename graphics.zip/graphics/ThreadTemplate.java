package graphics;

import javax.swing.*;
import java.awt.*;

public class ThreadTemplate extends JFrame {

    public ThreadTemplate(){

        setBounds(300, 250, 600, 350);
        add(new DrawingPanel());
        setVisible(true);

    }

    public static void main(String[] args) {
        new ThreadTemplate();
    }

}
class DrawingPanel extends JPanel implements Runnable{
    Thread thread=null;
    Font textFont = new Font("Arial",Font.BOLD,40);
    String name = "Happy Cristmas";

    public DrawingPanel(){
        thread = new Thread(this);
        thread.start();
        y= getHeight();
    }
    int y;
    public void paint(Graphics g){
        int w = getWidth(),h = getHeight();
        g.setColor(Color.cyan);

        FontMetrics fontMetrics = g.getFontMetrics(textFont);
        int textWidth = fontMetrics.stringWidth(name);
        int x = (w-textWidth)/2;
        g.setFont(textFont);
        g.setColor(Color.blue);
        g.drawString(name,x,h/2);

    }
    int fps=30;
     @Override
    public void run(){

        while (true){
            repaint();
            try {
                thread.sleep(100/fps);

            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
     }

}
