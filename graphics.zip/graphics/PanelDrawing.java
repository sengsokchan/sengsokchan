package graphics;

import javax.swing.*;
import java.awt.*;

public class PanelDrawing extends JPanel {
    Font textFont = new Font("Arial",Font.BOLD,40);
    Font khFont = new Font("Khmer OS",Font.BOLD,40);
    String name = "Happy Cristmas";
    String fullname = "Happy New Year 2024";
    public PanelDrawing(){}
    public void paint(Graphics g){
        int w = getWidth(),h = getHeight();
        g.setFont(khFont);
        g.setColor(Color.cyan);
       // int gab = 20;

        /*
        String textKh= "ជំរាបសួរ";
        g.setColor(Color.blue);
        g.setFont(textFont);
        g.setFont(khFont);
        g.drawString(textKh,w/2-50,h/2);
        g.drawRect(gab,gab,w-gab*2,h-gab*2);
        */
        FontMetrics fontMetrics = g.getFontMetrics(textFont);
        int textWidth = fontMetrics.stringWidth(name);
        int x = (w-textWidth)/2;
        g.setFont(textFont);
        g.setColor(Color.blue);
        g.drawString(name,x,h/2);
        //g.drawString(fullname,w-fontMetrics.stringWidth(fullname), h/2+fontMetrics.getHeight());
        // g.fillRect(10,20,100,75);
        //setBackground(Color.blue);
    }
}
