package graphics;

import javax.swing.*;
import java.awt.*;

public class PanelDrawingThread extends JPanel implements Runnable{

    Font khFont = new Font("Khmer OS",Font.BOLD,40);
    String name = "សួស្ដី";
    Thread thread;
    public PanelDrawingThread(){
        thread = new Thread(this);
        thread.start();
    }
    int y=300;
    int x=300;
    int inc = 3;
    public void paint(Graphics g){
        int w = getWidth(),h = getHeight();
        g.clearRect(0,0,w,h);
        g.setColor(Color.blue);
        g.fillRect(0,0,w,h);

        g.setFont(khFont);
            g.setColor(Color.cyan);
        FontMetrics fm = g.getFontMetrics(khFont);
        int stringWidth = fm.stringWidth(name);

        /*
        //int x = (w-fm.stringWidth(name))/2;
        //g.drawString(name, x, y-=3);
        //if(y<0)y=h;
        */
        g.drawString(name, x-=3, h/2);
        if(x<-stringWidth)x=w;
    }

    int fps =30;
 @Override
    public void run() {
        while (true) {
            repaint();
            try {
                Thread.sleep(1000 / fps);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
