package Intro;

import javax.swing.*;
import java.awt.*;


public class GraphicText extends JFrame {
   DrawingPanel drawingPanel = new DrawingPanel();
  public  GraphicText() {
    add(drawingPanel);
    setBounds(400,250,500,500);

   // setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true);
  }

  public static void main(String[] args) {
    new  GraphicText();
  }
}
