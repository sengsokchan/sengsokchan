package Intro;

import javax.swing.*;
import java.awt.*;

public class ReviewLayoutManagerJpanel extends JFrame {
    JLabel jLabel = new JLabel("name");
    JTextField textField = new JTextField("Text Here",8);
    JButton button = new JButton("OK");

    public ReviewLayoutManagerJpanel(){
        setLayout(new FlowLayout());
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(jLabel); panel.add(textField); panel.add(button);
        add(panel);
        setBackground(Color.BLUE);
        setBounds(500,200,300,300);
        setVisible(true);
    }

    public static void main(String[] args) {

        new ReviewLayoutManagerJpanel();
    }
}
