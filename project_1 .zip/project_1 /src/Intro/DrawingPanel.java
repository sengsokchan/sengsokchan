package Intro;

import javax.swing.*;
import java.awt.*;
public class DrawingPanel extends JPanel {
   Font textFont = new Font("Arial",Font.BOLD,40);
    Font khFont = new Font("Khmer OS",Font.BOLD,40);
    String name = "Happy Cristmas";
    String name1 = "Happy New Year 2023";
    public DrawingPanel(){}
    public void paint(Graphics g){
        int w = getWidth(),h = getHeight();
        int gab = 20;

        /*
        String textKh= "ជំរាបសួរ";
        g.setColor(Color.blue);
        g.setFont(textFont);
        g.setFont(khFont);
        g.drawString(textKh,w/2-50,h/2);
        g.drawRect(gab,gab,w-gab*2,h-gab*2);
        */
        FontMetrics fontMetrics = g.getFontMetrics(textFont);
        int textWidth = fontMetrics.stringWidth(name);
        int x = (w-textWidth)/2;
        g.setFont(textFont);
        g.setColor(Color.blue);
        g.drawString(name,x,h/2);
        g.drawString(fullName,w-fontMetrics.stringWidth(name1),h/2+fontMetrics.getHeight());
        // g.fillRect(10,20,100,75);;
        //setBackground(Color.blue);
    }


 }
