package Intro;

import javax.swing.*;

public class ReviewLayoutManager extends JFrame{

    public void Review(){
        setBounds(400,300,500,300);
        setVisible(true);

    }

    public static void main(String[] args) {

        JFrame jframe = new JFrame("This is a frame");
        JLabel jLabel = new JLabel("hi");
        jframe.add(jLabel);
        jframe.setVisible(true);

    }
}
