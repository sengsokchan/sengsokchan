package Intro;

import javax.swing.*;
import java.awt.*;

public class ReviewLayoutManager2 extends JFrame {
    JLabel jLabel = new JLabel("name");
    JTextField textField = new JTextField("Text Here",8);
    JButton button = new JButton("OK");

    public ReviewLayoutManager2(){
        setLayout(new FlowLayout());
        add(jLabel); add(textField); add(button);
        setBounds(500,200,300,100);
        setVisible(true);
    }

    public static void main(String[] args) {
        new  ReviewLayoutManager2();
    }
}
