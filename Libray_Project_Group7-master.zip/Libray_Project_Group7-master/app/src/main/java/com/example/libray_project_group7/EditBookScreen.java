package com.example.libray_project_group7;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

import java.io.IOException;

public class EditBookScreen extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    ImageView editImageBook;
    Button onSaveButton,editImageCard;
    private Uri selectedImageUri;
    TextView editTextTitle, editTextDescription, editTextAuthor, editTextGenre;
    DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_edit_book_screen);
        editImageBook = findViewById(R.id.imageEditBook);
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextAuthor = findViewById(R.id.editTextAuthor);
        editTextGenre = findViewById(R.id.editTextGenre);
        onSaveButton = findViewById(R.id.buttonSave);
        helper = new DatabaseHelper(EditBookScreen.this);

        Bundle bundle = getIntent().getBundleExtra("bookData");
        if (bundle != null) {
            editTextTitle.setText(bundle.getString("title"));
            editTextAuthor.setText(bundle.getString("author"));
            editTextDescription.setText(bundle.getString("description"));
            editTextGenre.setText(bundle.getString("genre"));
            String photoUriString = bundle.getString("photo");
            if (photoUriString != null && !photoUriString.isEmpty()) {
                selectedImageUri = Uri.parse(photoUriString);
                Glide.with(this).load(selectedImageUri).into(editImageBook);
            }
        }
        editImageBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGallery();
            }
        });

    }
    public void onSaveButtonClickeds(View view) {
        int bookId = getIntent().getIntExtra("id",1);
        System.out.println("============boookID :" + bookId);
        String updatedTitle = editTextTitle.getText().toString();
        String updatedAuthor = editTextAuthor.getText().toString();
        String updatedDescription = editTextDescription.getText().toString();
        String updatedGenre = editTextGenre.getText().toString();
        String updatedPhoto = selectedImageUri != null ? selectedImageUri.toString() : "";


        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        long result = databaseHelper.updateBookData(bookId, updatedTitle, updatedAuthor, updatedDescription, updatedGenre, updatedPhoto);

        if (result > 0) {
            Toast.makeText(this, "Book updated successfully", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(this, MainActivity.class));
        } else {
            Toast.makeText(this, "Failed to update book", Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                editImageBook.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
