package com.example.libray_project_group7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String databaseName = "Sign_Up";
    private static final int databaseVersion = 2;

    public DatabaseHelper(Context context) {
        super(context, databaseName, null, databaseVersion);
        Log.d("DatabaseHelper", "Database path: " + context.getDatabasePath(databaseName));
    }

    @Override
    public void onCreate(SQLiteDatabase myDatabase) {
        Log.d("====================DatabaseHelper", "onCreate method called");
        myDatabase.execSQL("CREATE TABLE allusers(email TEXT PRIMARY KEY, password TEXT, bod DATE, photo TEXT)");
        myDatabase.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT,author TEXT,genre TEXT,photo TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDatabase, int i, int i1) {
        myDatabase.execSQL("DROP TABLE IF EXISTS allusers");
        myDatabase.execSQL("DROP TABLE IF EXISTS books");
        onCreate(myDatabase);
    }

    public boolean insertUserData(String email, String password, String bod, String photo) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("bod", bod);
        contentValues.put("photo", photo);
        long result = myDatabase.insert("allusers", null, contentValues);
        myDatabase.close();

        return result != -1;
    }
    public boolean updateUserData(String email, String password, String bod, String photo) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("password", password);
        contentValues.put("bod", bod);
        contentValues.put("photo", photo);

        // Use the WHERE clause to update the specific row based on email
        long result = myDatabase.update("allusers", contentValues, "email=?", new String[]{email});
        myDatabase.close();

        if (result > 0) {
            Log.d("DatabaseHelper", "updateUserData: Updated " + result + " rows");
        } else {
            Log.e("DatabaseHelper", "updateUserData: Update failed");
        }

        return result > 0;
    }

    public boolean deleteUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define the WHERE clause to identify the user by email
        String selection = "email = ?";
        String[] selectionArgs = {email};

        // Delete the user from the database
        int deletedRows = db.delete("allusers", selection, selectionArgs);

        // Close the database connection
        db.close();

        // Check if the user was deleted successfully
        return deletedRows > 0;
    }


    public Boolean checkEmail(String email) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        Cursor cursor = myDatabase.rawQuery("SELECT * FROM allusers WHERE email=?", new String[]{email});
        int count = cursor.getCount();
        cursor.close();

        return count > 0;
    }

    public Boolean booleanCheckEmailPassword(String email, String password) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        Cursor cursor = myDatabase.rawQuery("SELECT * FROM allusers WHERE email=? AND password=?", new String[]{email, password});

        boolean result = cursor.getCount() > 0;

        cursor.close();
        myDatabase.close();

        return result;
    }


    public long insertBookData(String title, String description, String author, String genre, String photo) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("description", description);  // Corrected order
        contentValues.put("author", author);  // Corrected order
        contentValues.put("genre", genre);
        contentValues.put("photo", photo);
        long result = myDatabase.insert("books", null, contentValues);
        myDatabase.close();
        if (result == -1) {
            Log.e("DatabaseHelper", "Failed to add book. Error code: " + result);
        }

        return result;
    }


    public Cursor getAllBooks() {
        SQLiteDatabase myDatabase = this.getReadableDatabase();
        return myDatabase.rawQuery("SELECT * FROM books", null);
    }

    public Cursor getBookById(int bookId) {
        SQLiteDatabase myDatabase = this.getReadableDatabase();
        return myDatabase.rawQuery("SELECT * FROM books WHERE id=?", new String[]{String.valueOf(bookId)});
    }

    public long updateBookData(int bookId, String title, String author, String description, String genre, String photo) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("author", author);
        contentValues.put("description", description);
        contentValues.put("genre", genre);
        contentValues.put("photo", photo);
        int result = myDatabase.update("books", contentValues, "id=?", new String[]{String.valueOf(bookId)});
        myDatabase.close();

        return result;
    }

    public boolean deleteBook(int bookId) {
        SQLiteDatabase myDatabase = this.getWritableDatabase();
        int result = myDatabase.delete("books", "id=?", new String[]{String.valueOf(bookId)});
        myDatabase.close();
        return result > 0;
    }


    public String getPhotoByEmail(String email) {
        SQLiteDatabase myDatabase = this.getReadableDatabase();
        Cursor cursor = myDatabase.rawQuery("SELECT photo FROM allusers WHERE email=?", new String[]{email});
        String photo = "";

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex("photo");
            if (columnIndex != -1) {
                photo = cursor.getString(columnIndex);
            }
        }

        cursor.close();
        myDatabase.close();

        return photo;
    }

    public String getBodByEmail(String email) {
        SQLiteDatabase myDatabase = this.getReadableDatabase();
        Cursor cursor = myDatabase.rawQuery("SELECT bod FROM allusers WHERE email=?", new String[]{email});
        String bod = "";

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex("bod");
            if (columnIndex != -1) {
                bod = cursor.getString(columnIndex);
            }
        }

        cursor.close();
        myDatabase.close();

        return bod;
    }
}
