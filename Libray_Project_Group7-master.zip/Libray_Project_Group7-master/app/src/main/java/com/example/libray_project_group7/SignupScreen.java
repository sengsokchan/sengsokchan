package com.example.libray_project_group7;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class SignupScreen extends AppCompatActivity {

    EditText editTextEmail, editTextPassword, editTextConfirmPassword, bodEditText;
    Button btnSignup, uploadButton;
    ImageView imageViewProfile;
    DatabaseHelper databaseHelper;
    DatePickerDialog.OnDateSetListener dateSetListener;
    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_signup_screen);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editPassword);
        editTextConfirmPassword = findViewById(R.id.editConfirmPassword);
        btnSignup = findViewById(R.id.btnSignup);
        bodEditText = findViewById(R.id.bodEditText);
        imageViewProfile = findViewById(R.id.imageViewProfile);
        uploadButton = findViewById(R.id.uploadButton);

        databaseHelper = new DatabaseHelper(this);

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                bodEditText.setText(selectedDate);
            }
        };

        bodEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageChooser();
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signUp();
            }
        });
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();

            try {
                // Load the selected image into imageViewProfile
                imageViewProfile.setImageURI(imageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void signUp() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();
        String bod = bodEditText.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || bod.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Password and Confirm Password do not match", Toast.LENGTH_SHORT).show();
        } else {
            if (databaseHelper.checkEmail(email)) {
                Toast.makeText(this, "Email already exists, please choose another", Toast.LENGTH_SHORT).show();
            } else {
                // Save the photo path in SharedPreferences only if an image is selected
                String photoPath = (imageUri != null) ? imageUri.toString() : "";
                savePhotoPathInSharedPreferences(photoPath);

                if (databaseHelper.insertUserData(email, password, bod, photoPath)) {
                    Toast.makeText(this, "Sign up successful", Toast.LENGTH_SHORT).show();

                    // Set the hasSignedUp preference after successful sign-up
                    SharedPreferences sharedPreferences = getSharedPreferences(LoginScreen.PREF_NAME, 0);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("hasSignedUp", true);
                    editor.putString("user_email", email);
                    editor.putString("user_bod", bod);
                    editor.apply();

                    // Pass the email to AdminProfile activity
                    Intent intent = new Intent(getApplicationContext(), AdminProfile.class);
                    intent.putExtra("user_email", email);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Sign up failed", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void savePhotoPathInSharedPreferences(String photoPath) {
        SharedPreferences sharedPreferences = getSharedPreferences(LoginScreen.PREF_NAME, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("user_photo", photoPath);
        editor.apply();

        Log.d("PhotoPath", "Saved Photo Path: " + photoPath);
    }
}
