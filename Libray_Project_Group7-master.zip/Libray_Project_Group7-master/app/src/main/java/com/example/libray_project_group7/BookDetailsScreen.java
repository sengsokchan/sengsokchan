package com.example.libray_project_group7;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

public class BookDetailsScreen extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_book_details_screen);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String title = extras.getString("title");
            String description = extras.getString("description");
            String author = extras.getString("author");
            String genre = extras.getString("genre");
            String photo = extras.getString("photo");

            Log.d("PhotoURL", "Photo URL: " + photo);
            TextView titleView = findViewById(R.id.titleView);
            TextView genreView = findViewById(R.id.genreView);
            TextView authorView = findViewById(R.id.authorView);
            TextView descriptionView = findViewById(R.id.descriptionTextView);
            ImageView imageView = findViewById(R.id.imageView);

            titleView.setText(title);
            genreView.setText(genre);
            descriptionView.setText(description);
            authorView.setText(author);

            Glide.with(this)
                    .load(Uri.parse(photo))
                    .placeholder(R.drawable.defaultbook)
                    .error(R.drawable.help)
                    .into(imageView);
        }
    }
}
