// Book.java
package com.example.libray_project_group7;

public class Book {
    private  int id;
    private String title;
    private String description;
    private String author;
    private String genre;
    private String photo;

    // Constructors, getters, and setters
    public Book() {
        // Default constructor
    }

    public Book(int id,String title, String description, String author, String genre, String photo) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.author = author;
        this.genre = genre;
        this.photo = photo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPhoto() {
        return photo;
    }
    public  int getId(){return id;}

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
