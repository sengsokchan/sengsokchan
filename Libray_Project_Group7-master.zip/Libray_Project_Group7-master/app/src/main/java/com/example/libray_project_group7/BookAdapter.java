package com.example.libray_project_group7;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {
    private List<Book> bookList;
    Context context;
    DatabaseHelper databaseHelper;


    public BookAdapter(List<Book> bookList,Context context) {
        this.bookList = bookList;
        this.context = context;
        this.databaseHelper = new DatabaseHelper(context);

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       // View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_book, parent, false);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view1 = inflater.inflate(R.layout.item_book,null);
        return new ViewHolder(view1);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Book book = bookList.get(position);
        holder.titleTextView.setText(book.getTitle());
        holder.authorTextView.setText(book.getAuthor());
        holder.genreTextView.setText(book.getGenre());


        if (book.getPhoto() != null && !book.getPhoto().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                    .load(book.getPhoto())
                    .into(holder.photoImageView);
        } else {
            holder.photoImageView.setImageResource(R.drawable.defaultbook);
        }

        holder.menuButton.setOnClickListener(v -> showPopupMenu(holder.menuButton, position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (context != null) {
                    Book book = bookList.get(position);
                    Intent i = new Intent(context, BookDetailsScreen.class);
                    i.putExtra("title", book.getTitle());
                    i.putExtra("description", book.getDescription());
                    i.putExtra("author", book.getAuthor());
                    i.putExtra("genre", book.getGenre());
                    i.putExtra("photo", book.getPhoto());
                    context.startActivity(i);
                } else {
                    Toast.makeText(v.getContext(), "Context is null", Toast.LENGTH_SHORT).show();
                }

            }
        });}

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, authorTextView, genreTextView;
        ImageView photoImageView;
        Button menuButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleBook);
            authorTextView = itemView.findViewById(R.id.authorBook);
            genreTextView = itemView.findViewById(R.id.genreBook);
            photoImageView = itemView.findViewById(R.id.bookImageView);
            menuButton = itemView.findViewById(R.id.menuButton);

        }
    }

    private void showPopupMenu(View view, int position) {
        PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.book_menu, popupMenu.getMenu());
        Book book = bookList.get(position);
        popupMenu.setOnMenuItemClickListener(item -> {

            switch (item.getItemId()) {
                case R.id.book_edit:
                    Bundle bundle = new Bundle();
                    bundle.putString("title", book.getTitle());
                    bundle.putString("description", book.getDescription());
                    bundle.putString("author", book.getAuthor());
                    bundle.putString("genre", book.getGenre());
                    bundle.putString("photo", book.getPhoto());
                    Intent intent = new Intent(context, EditBookScreen.class);
                    intent.putExtra("bookData", bundle);
                    context.startActivity(intent);
                    return true;
                case R.id.book_delete:
                    deleteItem(position);
                    return true;
                default:
                    return false;
            }
        });

        popupMenu.show();
    }



    private void deleteItem(int position) {
        Book book = bookList.get(position);
        int bookId = book.getId();
        databaseHelper.deleteBook(bookId);
        bookList.remove(position);
        notifyItemRemoved(position);
    }



    public void updateBookList(List<Book> updatedBookList) {
        bookList.clear();
        bookList.addAll(updatedBookList);
        notifyDataSetChanged();
    }

}
