package com.example.libray_project_group7;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;

public class AddBookScreen extends AppCompatActivity {
    private EditText titleEditText, descriptionEditText, authorEditText, genreEditText;
    private ImageView photoPreview;
    private DatabaseHelper dbHelper;
    private Uri selectedImageUri;
    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_add_book_screen);
        titleEditText = findViewById(R.id.titleEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        authorEditText = findViewById(R.id.authorEditText);
        genreEditText = findViewById(R.id.genreEditText);
        photoPreview = findViewById(R.id.photoPreview);
        Button selectImageButton = findViewById(R.id.selectImageButton);
        Button addButton = findViewById(R.id.addButton);

        selectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }

        });


    }

    private void add() {
        dbHelper = new DatabaseHelper(this);
        String title = titleEditText.getText().toString();
        String author = descriptionEditText.getText().toString();
        String description = authorEditText.getText().toString();
        String genre = genreEditText.getText().toString();
        String photo = selectedImageUri != null ? selectedImageUri.toString() : "";

        long insertedId = dbHelper.insertBookData(title, author,description, genre, photo);

        if (insertedId != -1) {
            Toast.makeText(AddBookScreen.this, "Book added successfully", Toast.LENGTH_SHORT).show();

            // Navigate back to MainActivity
            Intent intent = new Intent(AddBookScreen.this, MainActivity.class);
            startActivity(intent);
            finish();  // Optional: Close the AddBookScreen if needed
        } else {
            Toast.makeText(AddBookScreen.this, "Failed to add book", Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                photoPreview.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
