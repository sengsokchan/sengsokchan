package com.example.libray_project_group7;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity {

    public static final String PREF_NAME = "MyPrefs";
    EditText editTextEmail, editTextPassword;
    Button btnLogin;
    DatabaseHelper databaseHelper;
    TextView textViewCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_login);

        editTextEmail = findViewById(R.id.editTextEmailAddress);
        editTextPassword = findViewById(R.id.editTextNumberPassword2);
        btnLogin = findViewById(R.id.loginButton);

        databaseHelper = new DatabaseHelper(this);
        textViewCreateAccount = findViewById(R.id.textView6);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Call the login method to validate email and password
                login();
            }
        });

        textViewCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginScreen.this, SignupScreen.class));
            }
        });
    }

    private void login() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else {
            if (databaseHelper.booleanCheckEmailPassword(email, password)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Fetch the bod and photo corresponding to the logged-in email
                String bod = databaseHelper.getBodByEmail(email);
                String photo = databaseHelper.getPhotoByEmail(email);

                // Set the hasLoggedIn preference after successful login
                SharedPreferences sharedPreferences = getSharedPreferences(LoginScreen.PREF_NAME, 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("hasLoggedIn", true);
                editor.putString("user_email", email); // Save email in SharedPreferences
                editor.putString("user_bod", bod);     // Save bod in SharedPreferences
                editor.putString("user_photo", photo); // Save photo in SharedPreferences
                editor.apply();

                // Pass the email to AdminProfile activity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("user_email", email);
                startActivity(intent);
                finish(); // Close the LoginScreen activity
            } else {
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
            }
        }
    }


    public void onCreateAccountClick(View view) {
        startActivity(new Intent(LoginScreen.this, SignupScreen.class));
    }
}