package com.example.libray_project_group7;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AdminProfile extends AppCompatActivity {

    Button btnLogOut;
    TextView textViewEditProfile, textViewName, textViewNumber, addBook, textViewDeleteAcc;
    ImageButton imageButtonBack;

    public void onBackIcon(View view) {
        // Handle the click event for the back icon

        // Assuming you want to go to MainActivity
        Intent intent = new Intent(AdminProfile.this, MainActivity.class);
        startActivity(intent);
        finish(); // Optional: Close the current activity if needed
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_admin_profile);

        btnLogOut = findViewById(R.id.btnLogOut);
        textViewEditProfile = findViewById(R.id.textViewEditProfile);
        textViewName = findViewById(R.id.textViewName);
        textViewNumber = findViewById(R.id.textViewNumber);
        addBook = findViewById(R.id.addBooks);
        textViewDeleteAcc = findViewById(R.id.textViewDeleteAcc); // Add this line

        SharedPreferences sharedPreferences = getSharedPreferences(LoginScreen.PREF_NAME, 0);
        String userEmail = sharedPreferences.getString("user_email", "");
        String bod = sharedPreferences.getString("user_bod", "");
        String photoPath = sharedPreferences.getString("user_photo", ""); // Retrieve the saved photo path

        addBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminProfile.this, AddBookScreen.class));
            }
        });

        // Display user information
        if (!userEmail.isEmpty()) {
            textViewName.setText(userEmail);
        }
        if (!bod.isEmpty()) {
            textViewNumber.setText(bod);
        }

        textViewEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminProfile.this, ChangeAdminInfoScreen.class));
            }
        });

        textViewDeleteAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle user deletion
                deleteUser();
            }
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearAuthenticationInfo();
                Intent intent = new Intent(AdminProfile.this, LoginScreen.class);
                startActivity(intent);
                finish();
            }

            private void clearAuthenticationInfo() {
                SharedPreferences preferences = getSharedPreferences(LoginScreen.PREF_NAME, MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.remove("hasLoggedIn");
                editor.remove("user_email");
                editor.remove("user_bod");
                editor.remove("user_photo");
                editor.apply();
            }
        });

        ImageView profileImageView = findViewById(R.id.ProfileimageView);
        if (!photoPath.isEmpty()) {
            Glide.with(this)
                    .load(Uri.parse(photoPath))
                    .placeholder(R.drawable.defaultprofile)
                    .error(com.denzcoskun.imageslider.R.drawable.error)
                    .into(profileImageView);
        }
    }

    private void deleteUser() {
        try {
            // Get the user email from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences(LoginScreen.PREF_NAME, MODE_PRIVATE);
            String email = sharedPreferences.getString("user_email", "");

            // Create an instance of DatabaseHelper
            DatabaseHelper dbHelper = new DatabaseHelper(AdminProfile.this);

            // Call the deleteUser method to delete the user
            boolean isDeleted = dbHelper.deleteUser(email);

            if (isDeleted) {
                // User deleted successfully
                Log.d("DeleteUser", "User deleted successfully");

                // Remove user information from SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove("hasLoggedIn");
                editor.remove("user_email");
                editor.remove("user_bod");
                editor.remove("user_photo");
                editor.apply();

                // Navigate to the login screen
                Intent intent = new Intent(AdminProfile.this, LoginScreen.class);
                startActivity(intent);
                finish(); // Close the current activity
            } else {
                // Failed to delete user
                Log.e("DeleteUser", "Failed to delete user");
                // You can show a message or handle the failure in any other way
                Toast.makeText(AdminProfile.this, "Failed to delete user", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            // Log any exception that occurred
            Log.e("DeleteUser", "Exception: " + e.getMessage());
            e.printStackTrace();
            Toast.makeText(AdminProfile.this, "An error occurred", Toast.LENGTH_SHORT).show();
        }
    }
}
