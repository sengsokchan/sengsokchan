package com.example.libray_project_group7;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class EditBookActivity extends AppCompatActivity {
    private EditText editTitle, editAuthor, editGenre, editDescription;
    private Button btnSave;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_book);

        editTitle = findViewById(R.id.editTitle);
        editAuthor = findViewById(R.id.editAuthor);
        editGenre = findViewById(R.id.editGenre);
        editDescription = findViewById(R.id.editDescription);
        btnSave = findViewById(R.id.btnSave);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("bookId")) {
            int bookId = intent.getIntExtra("bookId", -1);
            Book book = fetchBookDetails(bookId);

            if (book != null) {
                editTitle.setText(book.getTitle());
                editAuthor.setText(book.getAuthor());
                editGenre.setText(book.getGenre());
                editDescription.setText(book.getDescription());
            }
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBookDetailsInDatabase();
                finish();
            }
        });
    }

    private Book fetchBookDetails(int bookId) {
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        return null;
    }

    // TODO: Implement the method to update book details in the database
    private void updateBookDetailsInDatabase() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
    }
}