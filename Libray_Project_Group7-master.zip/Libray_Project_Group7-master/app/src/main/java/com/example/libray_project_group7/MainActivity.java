package com.example.libray_project_group7;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseHelper databaseHelper;
    private BookAdapter bookAdapter;

    BottomNavigationView bottomNavView;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        bottomNavView = findViewById(R.id.bottomNavView);
        bottomNavView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        showToast("Home clicked");
                        return true;

                    case R.id.add:
                        showToast("Dashboard clicked");
                        startActivity(new Intent(MainActivity.this, AddBookScreen.class));
                        return true;

                    case R.id.profile:
                        startActivity(new Intent(MainActivity.this, AdminProfile.class));
                        return true;

                    default:
                        return false;
                }
            }
        });




        ImageSlider imageSlider = (ImageSlider) findViewById(R.id.imageSlider);
        ArrayList<SlideModel> slideModels = new ArrayList<>();
        slideModels.add(new SlideModel(R.drawable.slider1, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.slider2, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.slider3, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.slider4, ScaleTypes.FIT));
        imageSlider.setImageList(slideModels,ScaleTypes.FIT);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        databaseHelper = new DatabaseHelper(this);
        List<Book> bookList = getAllBooksFromDatabase();

        bookAdapter = new BookAdapter(bookList,MainActivity.this);
        recyclerView.setAdapter(bookAdapter);
        createDirectory();

    }

    private void createDirectory() {
        File directory = new File(getExternalFilesDir(null), "bookPhoto");

        if (!directory.exists()) {
            if (directory.mkdirs()) {
                Log.d("DirectoryCreation", "Directory created successfully");
            } else {
                Log.e("DirectoryCreation", "Failed to create directory");
            }
        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        List<Book> updatedBookList = getAllBooksFromDatabase();
        bookAdapter.updateBookList(updatedBookList);
    }

    private List<Book> getAllBooksFromDatabase() {
        List<Book> bookList = new ArrayList<>();
        Cursor cursor = databaseHelper.getAllBooks();

        while (cursor.moveToNext()) {
            @SuppressLint("Range")
            String title = cursor.getString(cursor.getColumnIndex("title"));
            @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex("description"));
            @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex("author"));
            @SuppressLint("Range") String genre = cursor.getString(cursor.getColumnIndex("genre"));
            @SuppressLint("Range") String photo = cursor.getString(cursor.getColumnIndex("photo"));
            int bookId = getIntent().getIntExtra("id", -1);
            Book book = new Book(bookId,title,description, author,genre,photo);
            bookList.add(book);
        }
        cursor.close();
        return bookList;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


}
