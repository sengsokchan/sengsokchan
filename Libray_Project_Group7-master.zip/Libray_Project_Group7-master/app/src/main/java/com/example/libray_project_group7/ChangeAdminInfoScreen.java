package com.example.libray_project_group7;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class ChangeAdminInfoScreen extends AppCompatActivity {

    EditText editTextEmailChange, editPasswordChange, editConfirmPasswordChange, bodEditTextChange, editOldPassword;
    Button editButton, uploadButtonChange;
    ImageView imageViewProfileChange;
    DatabaseHelper databaseHelper;
    ImageButton BackimageButton;
    DatePickerDialog.OnDateSetListener dateSetListener;
    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.activity_change_admin_info_screen);

        editTextEmailChange = findViewById(R.id.editTextEmailChange);
        editPasswordChange = findViewById(R.id.editPasswordChange);
        editConfirmPasswordChange = findViewById(R.id.editConfirmPasswordChange);
        editOldPassword = findViewById(R.id.editOldPassword);
        editButton = findViewById(R.id.editButton);
        bodEditTextChange = findViewById(R.id.bodEditTextChange);
        imageViewProfileChange = findViewById(R.id.imageViewProfileChange);
        uploadButtonChange = findViewById(R.id.uploadButtonChange);

        databaseHelper = new DatabaseHelper(this);
        BackimageButton = findViewById(R.id.BackimageButton);
        BackimageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ChangeAdminInfoScreen.this, AdminProfile.class));
            }
        });
        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                bodEditTextChange.setText(selectedDate);
            }
        };

        bodEditTextChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        uploadButtonChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageChooser();
            }
        });

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateUser(); // Call updateUser instead of signUp
            }
        });
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();

            try {
                // Load the selected image into imageViewProfile
                imageViewProfileChange.setImageURI(imageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    private void updateUser() {
        String email = editTextEmailChange.getText().toString().trim();
        String oldPassword = editOldPassword.getText().toString().trim();
        String newPassword = editPasswordChange.getText().toString().trim();
        String confirmPassword = editConfirmPasswordChange.getText().toString().trim();
        String bod = bodEditTextChange.getText().toString().trim();

        if (email.isEmpty() || oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty() || bod.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else {
            // Check if the old password is correct
            if (databaseHelper.booleanCheckEmailPassword(email, oldPassword)) {
                // Check if the new password and confirm password match
                if (newPassword.equals(confirmPassword)) {
                    // Save the photo path in SharedPreferences
                    String photoPath = imageUri != null ? imageUri.toString() : "";

                    // Update user information
                    if (databaseHelper.updateUserData(email, newPassword, bod, photoPath)) {
                        Toast.makeText(this, "Update successful", Toast.LENGTH_SHORT).show();

                        // Set the hasSignedUp preference after successful update
                        SharedPreferences sharedPreferences = getSharedPreferences(LoginScreen.PREF_NAME, 0);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean("hasSignedUp", true);
                        editor.putString("user_email", email);
                        editor.putString("user_bod", bod);
                        editor.apply();

                        // Pass the email to AdminProfile activity
                        Intent intent = new Intent(getApplicationContext(), AdminProfile.class);
                        intent.putExtra("user_email", email);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "New password and confirm password do not match", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Old password is incorrect", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
