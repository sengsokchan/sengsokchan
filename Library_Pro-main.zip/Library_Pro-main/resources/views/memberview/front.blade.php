<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        main {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        a {
            text-decoration: none;
            color: #3498db;
        }

        a:hover {
            color: #e74c3c;
        }

        button {
            background-color: red;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #c0392b;
        }
    </style>
    <title>Member List</title>
</head>
<body>

<header>
    <h1>Member List</h1>
</header>

<main>
    <a href="{{ route("member.create") }}" style="text-decoration: none; color: #fff; background-color: #3498db; padding: 10px 15px; border-radius: 4px;">Add New</a>

    <table>
        <thead>
            <tr>
                <th>memID</th>
                
                <th>memName</th>
                <th>MemPhone</th>
                <th>memJoinDate</th>
                <th>BOD</th>
                
            </tr>
        </thead>
        <tbody>
            @foreach($memberList as $m)
                <tr>
                    <td>{{ $m->memID }}</td>
                    <td>{{ $m->memName }}</td>
                    <td>{{ $m->MemPhone }}</td>
                    <td>{{ $m->memJoinDate }}</td>
                    <td>{{ $m->BOD }}</td>
                    <td>
                        <a href="{{ route("member.show", $m->memID) }}">View</a> 
                        <!--<a href="{{ route("book.edit", $b->bookID) }}">Edit</a> | 
                        <form action="{{ route("book.destroy", $b->bookID) }}" method="post" style="display: inline;">

                            @csrf
                            @method('DELETE')
                            <button type="submit">DELETE</button>
                        </form>-->
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</main>

</body>
</html>
