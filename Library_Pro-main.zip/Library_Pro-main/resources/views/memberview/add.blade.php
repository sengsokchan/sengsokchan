<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        form {
            max-width: 400px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        p {
            margin-bottom: 15px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        button {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #27ae60;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            color: #3498db;
            margin-top: 10px;
        }

        a:hover {
            color: #2980b9;
        }
    </style>
    <title>Add New Member</title>
</head>
<body>

<form action="{{ route("member.store")}}" method="post">
    @csrf
    @method('POST')
    <h1>Add New Member</h1>
    <p>
        Member ID: <input type="text" name="memID" placeholder="Enter Member ID">
    </p>
    <p>
        Member Name: <input type="text" name="memName" placeholder="Enter Member Name">
    </p>
    <p>
        Member Phone: <input type="text" name="MemPhone" placeholder="Enter Phone">
    </p>
    <p>
        Join Date: <input type="datetime" name="memJoinDate" placeholder="Enter Member Join Date">
    </p>
    <p>
       BOD: <input type="datetime" name="BOD" placeholder="Enter Birth Date">
    </p>
    <button type="submit">INSERT</button>
    <a href="{{ route("member.index") }}">BACK</a>
</form>

</body>
</html>
