<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        form {
            max-width: 400px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        p {
            margin-bottom: 15px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        button {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #27ae60;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            color: #3498db;
            margin-top: 10px;
        }

        a:hover {
            color: #2980b9;
        }
    </style>
    <title>Add New Book</title>
</head>
<body>

<form action="{{ route("book.store")}}" method="post">
    @csrf
    @method('POST')
    <h1>Add New Book</h1>
    
    <p>
        Book Title: <input type="text" name="title" placeholder="Enter Book Title">
    </p>
    <p>
        Description: <input type="text" name="description" placeholder="Enter Description">
    </p>
    <p>
        Genre: <input type="text" name="Genre" placeholder="Enter Genre">
    </p>
    <p>
        Public Date: <input type="datetime" name="publicDate" placeholder="Enter Public Date">
    </p>
    <p>
        Author: <input type="text" name="author" placeholder="Enter Author Name">
    </p>
    <p>
        Photo: <input type="text" name="Photo" placeholder="Enter Photo">
    </p>
    <button type="submit">INSERT</button>
    <a href="{{ route("book.index") }}">BACK</a>
</form>

</body>
</html>
