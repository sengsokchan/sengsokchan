<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            width: 400px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        p {
            margin-bottom: 15px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #2980b9;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            color: #3498db;
            margin-top: 10px;
        }

        a:hover {
            color: #2980b9;
        }
    </style>
    <title>Change Book Details</title>
</head>
<body>

<form action="{{ route("book.update", $item->bookID) }}" method="post">
    @csrf
    @method('PATCH')
    <h1>Change Book Details</h1>
    <p>
        <label for="title">Book Title:</label>
        <input type="text" id="title" name="title" value="{{$item->title}}" placeholder="Enter Book Title">
    </p>
    <p>
        <label for="description">Description:</label>
        <input type="text" id="description" name="description" value="{{$item->description}}" placeholder="Enter Description">
    </p>
    <p>
        <label for="Genre">Genre:</label>
        <input type="text" id="Genre" name="Genre" value="{{$item->Genre}}" placeholder="Enter Genre">
    </p>
    <p>
        <label for="publicDate">Public Date:</label>
        <input type="text" id="publicDate" name="publicDate" value="{{$item->publicDate}}" placeholder="Enter Public Date">
    </p>
    <p>
        <label for="author">Author:</label>
        <input type="text" id="author" name="author" value="{{$item->author}}" placeholder="Enter Author">
    </p>
    <p>
        <label for="photo">Photo:</label>
        <input type="text" id="photo" name="photo" value="{{$item->photo}}" placeholder="Enter Photo">
    </p>
    
    <button type="submit">UPDATE</button>
    <a href="{{ route("book.index") }}">BACK</a>
</form>

</body>
</html>
