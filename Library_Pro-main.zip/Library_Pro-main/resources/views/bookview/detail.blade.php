<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
        }

        .details-box {
            margin-bottom: 20px;
        }

        h1, h3 {
            color: #333;
            margin: 10px 0;
        }

        hr {
            border: 0;
            height: 1px;
            background: #dee2e6;
            margin: 20px 0;
        }

        a, button {
            display: inline-block;
            text-decoration: none;
            color: #ffffff;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        a {
            background-color: #007bff;
            border: 1px solid #007bff;
        }

        a:hover {
            background-color: #0056b3;
        }

        button {
            background-color: #dc3545;
            border: 1px solid #dc3545;
        }

        button:hover {
            background-color: #c82333;
        }
    </style>
    <title>Book Detail</title>
</head>
<body>

<div class="container">
    <div class="details-box">
        <h1>Food Detail</h1>
        <h3>Book ID: {{ $item->bookID }}</h3>
        <h3>Title: {{ $item->title }}</h3>
        <h3>Description: {{ $item->description }}</h3>
        <h3>Genre: {{$item->Genre}}</h3>
        <h3>Public Date: {{$item->publicDate}}</h3>
        <h3>Author: {{$item->author}}</h3>
        <h3>Photo: {{$item->photo}}</h3>
    </div>
    <hr>
    <div>
        <a href="{{ route("book.index") }}">Back to List</a>

        <!-- Update Button -->
        <form action="{{ route("book.edit", $item->bookID) }}" method="get" style="display: inline;">
        @csrf
        <button type="submit">Edit</button>
        </form>


        <!-- Delete Button -->
        <form action="{{ route("book.destroy", $item->bookID) }}" method="post" style="display: inline;">
            @csrf
            @method('DELETE')
            <button type="submit">Delete</button>
        </form>
    </div>
</div>

</body>
</html>
