<?php

namespace App\Http\Controllers;

use App\Models\MemberModel;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    //Display a listing of the resource.
    public function index()
    {
        //
        $memberList = MemberModel::all();
        return view ("memberview/front", compact("memberList"));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view("memberview.add");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        // return $request; //debug only

        $this->validate($request, [
            "memID" => "required",
            "memName" => "required",
            "MemPhone" => "required",
            "memJoinDate" => "required",
            "memJoinDate" => "required"
        ]);
        MemberModel::create($request->all());
        return redirect()->route("member.index");

    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        //
        $item = MemberModel::find($id);
        return view("memberview.detail", compact("item"));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $item = MemberModel::find($id);
        return view("memberview.change", compact("item"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
    $this->validate($request, [
        "memID" => "required",
        "memName" => "required",
        "MemPhone" => "required",
        "memJoinDate" => "required",
        "memJoinDate" => "required"
    ]);

    MemberModel::find($id)->update($request->all());
    return redirect()->route("member.index");
}


    /**food
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        MemberModel::find($id)->delete();
        return redirect()->route("member.index");
    }
}
