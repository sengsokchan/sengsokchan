<?php

namespace App\Http\Controllers;

use App\Models\BookModel;
use Illuminate\Http\Request;
use PhpParser\Node\Expr\Cast\Bool_;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $bookList = BookModel::all();
        return view ("bookview/front", compact("bookList"));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view("bookview.add");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        // return $request; //debug only

        $this->validate($request, [
            "title" => "required",
            "description" => "required",
            "Genre" => "required",
            "publicDate" => "required",
            "author" => "required",
            "Photo" => "required", // This makes the Photo field optional
        ]);
        BookModel::create($request->all());
        return redirect()->route("book.index");

    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        //
        $item = BookModel::find($id);
        return view("bookview.detail", compact("item"));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $item = BookModel::find($id);
        return view("bookview.change", compact("item"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
    $this->validate($request, [
        "title" => "required",
        "description" => "required",
        "Genre" => "required",
        "publicDate" => "required",
        "author" => "required",
        "Photo" => "required",
    ]);

    BookModel::find($id)->update($request->all());
    return redirect()->route("book.index");
}


    /**food
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        BookModel::find($id)->delete();
        return redirect()->route("book.index");
    }
}

