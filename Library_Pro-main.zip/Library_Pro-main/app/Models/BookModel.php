<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookModel extends Model
{
    use HasFactory;
    protected $table="book_tbl";
    protected $primaryKey="bookID";
    protected $fillable =["title","description","Genre","publicDate","author","Photo"];
    public $timestamps = false;
}
